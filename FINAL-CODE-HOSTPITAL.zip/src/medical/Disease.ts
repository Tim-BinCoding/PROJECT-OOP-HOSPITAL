/**
 * All hospital managed diseases types
 */
export enum Disease {
  STOMACH,
  CANCER,
  EYES,
  TEETH,
  EAR,
  NOSE,
}
